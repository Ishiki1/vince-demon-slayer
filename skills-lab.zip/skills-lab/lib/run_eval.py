#!/usr/bin/env python3
"""
Evaluation Orchestrator for Skills Lab.

Runs a skill against all test cases, judges each output against the rubric,
computes a weighted FINAL_SCORE, and saves outputs + detailed results.

Usage:
    python run_eval.py <campaign_dir>

Outputs:
    - Per-case outputs saved to <campaign_dir>/outputs/iter_<N>_case_<M>.md
    - Prints per-case dimension scores
    - Prints FINAL_SCORE: XX.X (the number the loop uses to decide keep/revert)
"""

import json
import os
import sys
import glob
import re
import yaml
from datetime import datetime

# Add lib/ to path for imports
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from judge import judge, compute_weighted_score
from generate_output import generate_output


def load_config(campaign_dir: str) -> dict:
    """Load campaign config.yaml."""
    config_path = os.path.join(campaign_dir, "config.yaml")
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def load_rubric(campaign_dir: str) -> tuple[str, dict]:
    """
    Load the eval rubric and parse dimension weights.

    Returns:
        (rubric_text, weights_dict) where weights_dict is {dimension: weight_float}
    """
    rubric_path = os.path.join(campaign_dir, "eval_rubric.md")
    with open(rubric_path, "r") as f:
        rubric_text = f.read()

    # Parse weights from markdown table
    # Expected format: | Dimension Name | XX% | Description |
    weights = {}
    for line in rubric_text.split("\n"):
        match = re.match(r'\|\s*\*?\*?(.+?)\*?\*?\s*\|\s*(\d+)%\s*\|', line)
        if match:
            dim_name = match.group(1).strip().strip("*")
            weight = int(match.group(2)) / 100.0
            weights[dim_name] = weight

    return rubric_text, weights


def load_campaign_brief(campaign_dir: str) -> str:
    """Load campaign brief if it exists."""
    brief_path = os.path.join(campaign_dir, "campaign_brief.md")
    if os.path.exists(brief_path):
        with open(brief_path, "r") as f:
            return f.read()
    return ""


def get_test_cases(campaign_dir: str) -> list[dict]:
    """
    Discover test cases in the campaign's test_cases/ directory.

    Returns list of dicts with 'data_path' and optional 'context_path'.
    """
    test_dir = os.path.join(campaign_dir, "test_cases")
    cases = []

    # Find data files (JSON or CSV), skip context files
    data_files = sorted(
        glob.glob(os.path.join(test_dir, "case_*.json")) +
        glob.glob(os.path.join(test_dir, "case_*.csv"))
    )

    for data_path in data_files:
        # Look for matching context file
        base = os.path.splitext(data_path)[0]
        # case_01.json -> case_01_context.md
        context_path = base + "_context.md"
        if not os.path.exists(context_path):
            # Try: case_01_healthy_team.json -> case_01_healthy_team_context.md
            context_path = ""

        cases.append({
            "data_path": data_path,
            "context_path": context_path,
            "name": os.path.basename(data_path),
        })

    return cases


def get_current_iteration(campaign_dir: str) -> int:
    """Get current iteration number from checkpoint or outputs."""
    checkpoint_path = os.path.join(campaign_dir, "checkpoint.json")
    if os.path.exists(checkpoint_path):
        with open(checkpoint_path, "r") as f:
            checkpoint = json.load(f)
            return checkpoint.get("current_iteration", 0)
    return 0


def save_output(campaign_dir: str, iteration: int, case_index: int,
                case_name: str, output_text: str) -> str:
    """Save generated output to the outputs/ directory."""
    outputs_dir = os.path.join(campaign_dir, "outputs")
    os.makedirs(outputs_dir, exist_ok=True)

    filename = f"iter_{iteration:03d}_case_{case_index:02d}_{case_name}.md"
    output_path = os.path.join(outputs_dir, filename)

    with open(output_path, "w") as f:
        f.write(output_text)

    return output_path


def run_eval(campaign_dir: str) -> float:
    """
    Run the full evaluation pipeline for a campaign.

    1. Load config, rubric, test cases
    2. For each test case: generate output + judge it
    3. Compute weighted FINAL_SCORE across all cases and dimensions
    4. Print FINAL_SCORE: XX.X

    Returns:
        The final weighted score.
    """
    # Load campaign files
    config = load_config(campaign_dir)
    rubric_text, weights = load_rubric(campaign_dir)
    campaign_brief = load_campaign_brief(campaign_dir)
    test_cases = get_test_cases(campaign_dir)
    skill_path = os.path.join(campaign_dir, "skill.md")

    model_id = config.get("model_id", "anthropic.claude-opus-4-6-v1")
    judge_model_id = config.get("judge_model_id", model_id)
    iteration = get_current_iteration(campaign_dir)

    if not test_cases:
        print("ERROR: No test cases found in test_cases/", file=sys.stderr)
        sys.exit(1)

    if not weights:
        print("ERROR: No dimension weights parsed from eval_rubric.md", file=sys.stderr)
        sys.exit(1)

    print(f"=== Skills Lab Evaluation ===")
    print(f"Campaign:    {os.path.basename(campaign_dir)}")
    print(f"Iteration:   {iteration}")
    print(f"Test cases:  {len(test_cases)}")
    print(f"Dimensions:  {len(weights)}")
    print(f"Model:       {model_id}")
    print(f"Judge model: {judge_model_id}")
    print(f"{'=' * 40}")
    print()

    all_case_scores = []

    for i, case in enumerate(test_cases):
        case_name = case["name"]
        print(f"--- Case {i+1}/{len(test_cases)}: {case_name} ---")

        # Step 1: Generate output
        print(f"  Generating output...")
        try:
            output_text = generate_output(
                skill_path=skill_path,
                test_case_path=case["data_path"],
                context_path=case.get("context_path", ""),
                model_id=model_id,
            )
        except Exception as e:
            print(f"  ERROR generating output: {e}", file=sys.stderr)
            all_case_scores.append(0.0)
            continue

        # Save output
        output_path = save_output(campaign_dir, iteration, i + 1, case_name, output_text)
        print(f"  Output saved: {output_path}")

        # Step 2: Judge output
        print(f"  Judging output...")
        try:
            judge_result = judge(
                output_text=output_text,
                rubric=rubric_text,
                campaign_brief=campaign_brief,
                model_id=judge_model_id,
            )
        except Exception as e:
            print(f"  ERROR judging output: {e}", file=sys.stderr)
            all_case_scores.append(0.0)
            continue

        # Print per-dimension scores
        scores = judge_result["scores"]
        reasoning = judge_result.get("reasoning", {})

        for dim, score in sorted(scores.items()):
            reason = reasoning.get(dim, "")
            weight = weights.get(dim, 0)
            print(f"  {dim:30s} {score:6.1f}  (weight: {weight:.0%}) {reason}")

        # Compute weighted score for this case
        case_score = compute_weighted_score(scores, weights)
        all_case_scores.append(case_score)
        print(f"  Case weighted score: {case_score:.1f}")
        print()

    # Compute final score (average across all cases)
    if all_case_scores:
        final_score = sum(all_case_scores) / len(all_case_scores)
    else:
        final_score = 0.0

    print(f"{'=' * 40}")
    print(f"Case scores: {[f'{s:.1f}' for s in all_case_scores]}")
    print(f"FINAL_SCORE: {final_score:.1f}")

    return final_score


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python run_eval.py <campaign_dir>", file=sys.stderr)
        print("Example: python run_eval.py campaigns/jira-analysis-v1", file=sys.stderr)
        sys.exit(1)

    campaign_dir = sys.argv[1]

    if not os.path.isdir(campaign_dir):
        print(f"ERROR: Campaign directory not found: {campaign_dir}", file=sys.stderr)
        sys.exit(1)

    try:
        score = run_eval(campaign_dir)
        sys.exit(0)
    except Exception as e:
        print(f"EVAL_ERROR: {e}", file=sys.stderr)
        sys.exit(1)
