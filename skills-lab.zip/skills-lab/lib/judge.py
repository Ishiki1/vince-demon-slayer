#!/usr/bin/env python3
"""
LLM-as-Judge via AWS Bedrock.

Sends a generated output + rubric to Claude and returns structured dimension scores.
Uses temperature=0 for reproducible scoring.
"""

import json
import sys
import boto3

MODEL_ID = "us.anthropic.claude-sonnet-4-20250514-v1:0"
REGION = "us-east-1"
MAX_TOKENS = 4000
TEMPERATURE = 0  # Deterministic judging


def build_judge_prompt(output_text: str, rubric: str, campaign_brief: str = "") -> str:
    """Construct the prompt that asks Claude to judge an output against a rubric."""
    brief_section = ""
    if campaign_brief.strip():
        brief_section = f"""
## Campaign Context
The following describes what the skill owner wants to improve and protect:

{campaign_brief}

Use this context to inform your scoring — reward improvements in the areas flagged as weak,
and penalize regressions in areas flagged as strengths to protect.
"""

    return f"""You are an expert evaluator. Your job is to score the following output against a rubric.

## Rubric
{rubric}

{brief_section}
## Output to Evaluate
{output_text}

## Instructions
Score each dimension listed in the rubric on a scale of 0-100.
- 0 = completely absent or wrong
- 25 = poor, major gaps
- 50 = adequate but unremarkable
- 75 = good, solid work
- 100 = exceptional, best-in-class

You MUST respond with ONLY a valid JSON object in this exact format:
{{
  "scores": {{
    "<dimension_name>": <integer_score>,
    ...
  }},
  "reasoning": {{
    "<dimension_name>": "<one_sentence_justification>",
    ...
  }}
}}

Do not include any text before or after the JSON object. Only output the JSON."""


def invoke_bedrock(prompt: str, model_id: str = MODEL_ID) -> str:
    """Call AWS Bedrock with the given prompt and return the response text."""
    client = boto3.client("bedrock-runtime", region_name=REGION)

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
    })

    response = client.invoke_model(modelId=model_id, body=body)
    response_body = json.loads(response["body"].read())

    # Handle Bedrock response format
    if "content" in response_body:
        return response_body["content"][0]["text"]
    elif "completion" in response_body:
        return response_body["completion"]
    else:
        raise ValueError(f"Unexpected Bedrock response format: {list(response_body.keys())}")


def parse_judge_response(response_text: str) -> dict:
    """Parse the judge's JSON response into scores and reasoning."""
    # Try to extract JSON from the response (handle markdown code blocks)
    text = response_text.strip()
    if text.startswith("```"):
        # Remove code block markers
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)

    result = json.loads(text)

    if "scores" not in result:
        raise ValueError(f"Judge response missing 'scores' key: {list(result.keys())}")

    # Validate all scores are 0-100
    for dim, score in result["scores"].items():
        if not isinstance(score, (int, float)) or score < 0 or score > 100:
            raise ValueError(f"Invalid score for '{dim}': {score} (must be 0-100)")

    return result


def judge(output_text: str, rubric: str, campaign_brief: str = "",
          model_id: str = MODEL_ID) -> dict:
    """
    Judge an output against a rubric using LLM-as-judge.

    Args:
        output_text: The generated output to evaluate.
        rubric: The evaluation rubric (markdown) with dimensions and weights.
        campaign_brief: Optional campaign context for focused scoring.
        model_id: AWS Bedrock model ID.

    Returns:
        dict with 'scores' (dimension -> int) and 'reasoning' (dimension -> str).
    """
    prompt = build_judge_prompt(output_text, rubric, campaign_brief)
    response_text = invoke_bedrock(prompt, model_id)
    return parse_judge_response(response_text)


def compute_weighted_score(scores: dict, weights: dict) -> float:
    """
    Compute weighted average score.

    Args:
        scores: {dimension: score} from the judge.
        weights: {dimension: weight} from the rubric (weights should sum to 1.0).

    Returns:
        Weighted average score (0-100).
    """
    total = 0.0
    weight_sum = 0.0

    for dim, weight in weights.items():
        if dim in scores:
            total += scores[dim] * weight
            weight_sum += weight

    if weight_sum == 0:
        return 0.0

    # Normalize in case weights don't sum to 1.0
    return total / weight_sum


if __name__ == "__main__":
    # Quick test: judge a sample output
    sample_output = "This is a test output."
    sample_rubric = """
    | Dimension | Weight | Description |
    |-----------|--------|-------------|
    | Clarity | 50% | Is the output clear? |
    | Depth | 50% | Is the output deep? |
    """

    try:
        result = judge(sample_output, sample_rubric)
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
