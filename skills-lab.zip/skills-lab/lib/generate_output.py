#!/usr/bin/env python3
"""
Output Generator for Skills Lab.

Runs a skill (markdown instructions) against test case data via AWS Bedrock,
producing the output that will be judged by the eval rubric.
"""

import json
import sys
import os
import boto3

MODEL_ID = "us.anthropic.claude-sonnet-4-20250514-v1:0"
REGION = "us-east-1"
MAX_TOKENS = 8000
TEMPERATURE = 0.3  # Slight creativity for generation, but mostly deterministic


def build_generation_prompt(skill_instructions: str, test_case_data: str,
                            test_case_context: str = "") -> str:
    """
    Build the prompt that asks Claude to execute a skill against test data.

    Args:
        skill_instructions: The full content of skill.md.
        test_case_data: The test case input data (CSV, JSON, etc.).
        test_case_context: Optional context about what the test case represents.
    """
    context_section = ""
    if test_case_context.strip():
        context_section = f"""
## Test Scenario Context
{test_case_context}
"""

    return f"""You are an expert analyst executing a skill according to the instructions below.
Follow these instructions precisely and produce the requested output.

## Skill Instructions
{skill_instructions}

{context_section}
## Input Data
{test_case_data}

## Task
Execute the skill instructions above against the provided input data.
Produce the complete output as specified in the skill instructions.
Be thorough, insightful, and actionable. This output will be evaluated for quality."""


def invoke_bedrock(prompt: str, model_id: str = MODEL_ID) -> str:
    """Call AWS Bedrock with the given prompt and return the response text."""
    client = boto3.client("bedrock-runtime", region_name=REGION)

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
    })

    response = client.invoke_model(modelId=model_id, body=body)
    response_body = json.loads(response["body"].read())

    if "content" in response_body:
        return response_body["content"][0]["text"]
    elif "completion" in response_body:
        return response_body["completion"]
    else:
        raise ValueError(f"Unexpected Bedrock response format: {list(response_body.keys())}")


def generate_output(skill_path: str, test_case_path: str,
                    context_path: str = "", model_id: str = MODEL_ID) -> str:
    """
    Generate output by running a skill against a test case.

    Args:
        skill_path: Path to the skill.md file.
        test_case_path: Path to the test case data file (JSON/CSV).
        context_path: Optional path to test case context file.
        model_id: AWS Bedrock model ID.

    Returns:
        Generated output text.
    """
    with open(skill_path, "r") as f:
        skill_instructions = f.read()

    with open(test_case_path, "r") as f:
        test_case_data = f.read()

    test_case_context = ""
    if context_path and os.path.exists(context_path):
        with open(context_path, "r") as f:
            test_case_context = f.read()

    prompt = build_generation_prompt(skill_instructions, test_case_data, test_case_context)
    return invoke_bedrock(prompt, model_id)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python generate_output.py <skill.md> <test_case.json> [context.md]",
              file=sys.stderr)
        sys.exit(1)

    skill = sys.argv[1]
    test_case = sys.argv[2]
    context = sys.argv[3] if len(sys.argv) > 3 else ""

    try:
        output = generate_output(skill, test_case, context)
        print(output)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
