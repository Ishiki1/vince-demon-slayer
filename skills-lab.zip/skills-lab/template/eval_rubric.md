# Evaluation Rubric

*Define the scoring dimensions and their weights. The run_eval.py parser reads the table below.*

## Scoring Scale
- **0** = Completely absent or wrong
- **25** = Poor, major gaps
- **50** = Adequate but unremarkable
- **75** = Good, solid work
- **100** = Exceptional, best-in-class

## Dimensions

| Dimension | Weight | Description |
|-----------|--------|-------------|
| Example Dimension 1 | 25% | Replace with actual dimension and description |
| Example Dimension 2 | 25% | Replace with actual dimension and description |
| Example Dimension 3 | 25% | Replace with actual dimension and description |
| Example Dimension 4 | 25% | Replace with actual dimension and description |

**Note:** Weights must sum to 100%. The dimension names in this table must match exactly what the LLM judge returns in its JSON scores.
