# Campaign Brief

*Populated by the kickoff wizard at campaign start.*

## What skill are we training?
<!-- Path to the original skill file, e.g. scripts/skills/jira-analysis.md -->

## What's working well? (Protect these)
<!-- List strengths of the current skill that must not regress -->

## What specific weaknesses do you want to fix?
<!-- Be specific: "recommendations are too generic", "doesn't catch bottlenecks" -->

## What does a perfect output look like?
<!-- Optional: paste an example or describe the qualities of an ideal output -->

## Any areas that are off-limits?
<!-- E.g., "don't change the output format", "keep the workflow section intact" -->

## Additional context
<!-- Anything else the researcher should know -->
