# Test Case 03: Stale-Heavy / Crisis Team

## Scenario
An OSO team in crisis: a contractor departed, most issues are stale (30+ days without updates), multiple service lines have no owners, and there's a massive data hygiene problem. 32 issues spanning 5+ months.

## Data Characteristics
- **Resolution rate**: Only 5 of 32 resolved (~16%), the rest are stuck
- **Stale issues**: 25 of 32 issues haven't been updated in 30+ days. 12 items are 100+ days stale.
- **Unassigned**: 17 of 32 issues have no assignee
- **On Hold**: Entire Attack Automation epic (OSO-5030) is On Hold for 126 days with no owner
- **Backlog rot**: Tradecraft epic (OSO-5010) has been in Backlog for 152 days — never started, no assignee, no labels
- **Missing metadata**: 14 items lack labels, 10 items lack Components — data hygiene is terrible
- **Staffing crisis**: A contractor departed (OSO-5053), knowledge transfer is incomplete (OSO-5054 stale 39 days), replacement hire hasn't started (OSO-5055)
- **Cycle times**: Active items average 100+ days with minimal progress

## What a Good Analysis Should Find
This is a team in urgent need of intervention:
1. **Emergency triage required**: 78% of issues are stale, many for 3+ months. This isn't normal aging — it's abandonment.
2. **Staffing crisis is the root cause**: Contractor departure + incomplete knowledge transfer = orphaned work. The hire hasn't started — when will capacity recover?
3. **Two entire service lines are dead**: Tradecraft (152 days, never started, no owner) and Attack Automation (126 days On Hold, no owner). These need immediate decisions: staff them or formally cancel/defer.
4. **Data hygiene is masking true state**: 44% of items lack labels, 31% lack Components. You can't manage what you can't see. Any dashboard or report built on this data will be misleading.
5. **Cloud security assessment is silently failing**: Epic OSO-5001 has been "In Progress" for 157 days but subtasks are stale 70-110 days. The epic status is a lie.
6. **APAC expansion is stalling**: Only 1 of 5 items done, regulatory analysis (high priority) stale 60 days. If this is strategic, it needs attention now.
7. **Risk projection**: At current velocity (5 resolved in 5 months = 1/month), clearing the 27 open items would take over 2 years. This is not sustainable.
8. **Budget request (OSO-5052) is urgent**: Q2 budget request hasn't started but Q2 is weeks away. Miss this and the team gets no additional resources.
9. **Recommendations should be triage-focused**: This isn't about optimization — it's about survival. The analysis should prioritize what to cancel, what to staff, and what to escalate.
