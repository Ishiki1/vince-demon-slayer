# Test Case 02: Bottlenecked Team

## Scenario
An OSO team with a severe single-point-of-failure: one person (Kowalski, Jan) is assigned to 15 of 30 issues across multiple service lines. Meanwhile, entire service lines are unowned and stalled.

## Data Characteristics
- **Resolution rate**: ~40% done, 2 cancelled, many stalled
- **Workload**: Extremely imbalanced — Kowalski has 15 issues, Rivera has 8, 7 issues are unassigned
- **Cycle times**: Kowalski's items average 50-70+ days due to overload
- **Stale issues**: Attack Automation epic is entirely On Hold/Backlog with zero assignees
- **Epic coverage**: Some tasks lack epic links and labels (OSO-4050, 4051, 4052, 4053)
- **On Hold items**: OSO-4030 and OSO-4031 are On Hold with no recent activity (48-55 days stale)
- **Missing labels**: Several items lack the oso2026 label, some lack Components

## What a Good Analysis Should Find
This data is screaming with problems — the analysis MUST catch:
1. **Critical bottleneck**: Kowalski is a single-point-of-failure across Adversary Emulation AND Tradecraft — if he's unavailable, two service lines stall
2. **Abandoned service line**: Attack Automation has ZERO assignees, all items On Hold or Backlog, no activity in 39-60 days
3. **Capacity crisis**: Kowalski has 5 To Do + 3 In Progress items — his queue is growing faster than he can resolve
4. **Risk cascade**: Phase 3 pen test (OSO-4005) is blocked behind phase 2 (OSO-4004), which Kowalski is still working on — the remediation report and stakeholder presentation are stacking up behind it
5. **Labeling inconsistency**: OSO-4014 and 4031 lack labels, multiple items lack Components
6. **Cross-team impact**: Kowalski is doing performance review prep (OSO-4050) on top of everything else
7. **Trend**: At current velocity, Kowalski cannot finish his To Do items before end of Q1
