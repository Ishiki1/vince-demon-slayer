# Test Case 01: Healthy Team

## Scenario
A well-functioning OSO team with 28 issues across 5 service lines over ~120 days.

## Data Characteristics
- **Resolution rate**: ~75% done, minimal cancellations
- **Workload**: Reasonably balanced across 10 team members
- **Cycle times**: Mostly 30-70 days, appropriate for the work
- **Stale issues**: Very few (2 To Do items, not urgent)
- **Epic coverage**: Most tasks linked to epics
- **Labels**: Consistent use of oso2026

## What a Good Analysis Should Find
Even in a healthy team, there are optimization opportunities:
- 2 tasks unassigned (OSO-3050, OSO-3052) — minor but worth noting
- Attack Automation epic is in progress but has a documentation task that hasn't started (OSO-3024, 34 days old)
- Service Delivery has the most in-progress items — is it understaffed relative to scope?
- Fechtner (Paul) is reporter on many items but not assigned — appropriate for Service Owner role
- Advisory knowledge base migration (OSO-3014) is the longest-running in-progress item at 45 days
- Tradecraft and Adversary Emulation are well-executed — could be models for other service lines
- The "Strategic_Fix" label appears only on one epic — inconsistent labeling
