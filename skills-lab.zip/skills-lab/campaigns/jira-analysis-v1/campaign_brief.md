# Campaign Brief — Jira Analysis v1

## What skill are we training?
`scripts/skills/jira-analysis.md` — The end-to-end Jira project analysis pipeline skill. It drives data pull, enrichment, computed metrics, Markdown report generation, and Word executive readouts for OSO (Offensive Security Operations) and BIRO teams at MSD/Merck.

## What's working well? (Protect these)
- The 5-step workflow pipeline is solid (Data Pull → Enrich → Compute → Report → Docx)
- Script CLI interfaces and naming are good
- Basic status distribution and workload reporting works
- Word export with embedded charts is a strong deliverable
- Team file integration for roster mapping

## What specific weaknesses do you want to fix?
- **Analysis depth**: Reports currently produce surface-level counts and percentages but lack structural insights about team dynamics and workflow health
- **Causal reasoning**: Reports say "20% of issues are stale" but don't explain WHY they're stale or what systemic factors contribute
- **Non-obvious patterns**: Missing hidden correlations, labeling inconsistencies that mask real issues, silent process failures
- **Bottleneck/risk detection**: Doesn't proactively flag single-points-of-failure, capacity risks, or deadline risks
- **Trend forecasting**: No forward-looking analysis based on velocity, backlog growth, or resolution rate trends
- **Recommendations quality**: Current recommendations are too generic ("triage stale issues") — need specific owners, timelines, expected impact
- **Visualization guidance**: Doesn't suggest which chart types would best reveal specific insights

## What does a perfect output look like?
A perfect Jira analysis report would:
1. Open with a crisp executive summary that tells a story, not just stats
2. Identify the 3 most important findings (not necessarily the most obvious)
3. Explain root causes with evidence from the data
4. Flag risks before they become crises, with severity ratings
5. Project where things are heading based on trends
6. Provide 5-7 specific, prioritized recommendations with owners, timelines, and expected impact
7. Suggest exactly which visualizations would be most revealing for each insight

## Any areas that are off-limits for changes?
- Do not change the 5-step workflow structure
- Do not rename scripts or change CLI interfaces
- Do not remove existing functionality — only add and refine
- Keep the team file integration approach

## Additional context
- This skill is used for both OSO and BIRO team analysis at MSD/Merck
- The primary audience is executives and service owners who need actionable intelligence, not just data dumps
- Paul is the Service Owner for OSO — the analysis needs to help him demonstrate value and identify improvements
- Test cases use synthetic data modeled after real OSO project patterns (567 issues, 5 service lines, 14 core team members)
