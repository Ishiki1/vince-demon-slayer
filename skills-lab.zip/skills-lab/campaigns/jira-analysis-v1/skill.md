# Skill: Jira Analysis

## Overview
- **Scripts**: `jira_query.py`, `enrich_comments.py`, `add_computed_columns.py`, `biro_full_report.py`, `biro_executive_docx.py`, `team_activity_pull.py`, `team_analysis.py`, `team_executive_docx.py`
- **Language**: Python 3
- **Auth**: `JIRA_TOKEN` env var or `--token` flag. PAT stored in `tokens/tokens.md`.
- **Dependencies**:
  - `python-docx` — Word export (`pip3 install python-docx`)
  - `matplotlib` — Charts/graphs (`pip3 install matplotlib`)
- **Depends on skill**: [Jira Query](jira-query.md)
- **Team file**: `reports/biro-team.md` — roster with Jira usernames, divisions, managers

## Description
End-to-end Jira project analysis pipeline. Pulls enriched data from Jira, adds computed metrics, generates a comprehensive Markdown report, and produces a Microsoft Word executive readout. Designed for a Service Owner to assess project health, team workload, and demonstrate value.

## Workflow

The analysis follows 5 steps. Each step produces an output that feeds the next.

```
Step 1: Data Pull (jira_query.py)
  ↓ CSVs with all columns
Step 2: Comment Enrichment (enrich_comments.py)
  ↓ CSVs + Last Comment columns
Step 3: Computed Columns (add_computed_columns.py)
  ↓ CSVs + Age, Cycle Time, Stale
Step 4: Markdown Report (biro_full_report.py)
  ↓ .md analysis file
Step 5: Word Executive Readout (biro_executive_docx.py)
  ↓ .docx formatted report
```

---

## Step 1: Data Pull

Uses the **Jira Query** skill. Pull epics and tasks separately with all enriched columns.

```bash
export JIRA_TOKEN="<from tokens/tokens.md>"

# Epics
python3 scripts/jira_query.py \
  --jql "project = BIRO AND issuetype = Epic ORDER BY created DESC" \
  --max 200 --output csv \
  --columns "Key,Summary,Status,Resolution,Priority,Assignee,Reporter,Labels,Components,Story Points,Created,Updated,Resolved,URL" \
  > reports/jira-analysis/csv/biro_epics_YYYY-MM-DD.csv

# Tasks (includes Epic column)
python3 scripts/jira_query.py \
  --jql "project = BIRO AND issuetype = Task ORDER BY created DESC" \
  --max 200 --output csv \
  --columns "Key,Summary,Status,Resolution,Priority,Assignee,Reporter,Epic,Labels,Components,Story Points,Created,Updated,Resolved,URL" \
  > reports/jira-analysis/csv/biro_tasks_YYYY-MM-DD.csv
```

### Full Column Set for Analysis

| Column | In Epics CSV | In Tasks CSV | Purpose |
|--------|:---:|:---:|---------|
| Key | ✓ | ✓ | Issue identifier |
| Summary | ✓ | ✓ | Description (80 chars) |
| Status | ✓ | ✓ | Workflow state |
| Resolution | ✓ | ✓ | Done, Duplicate, Won't Do, etc. |
| Priority | ✓ | ✓ | Low → Blocker |
| Assignee | ✓ | ✓ | Owner attribution |
| Reporter | ✓ | ✓ | Requestor tracking |
| Epic | — | ✓ | Links task to parent epic |
| Labels | ✓ | ✓ | Category tagging |
| Components | ✓ | ✓ | Capability area |
| Story Points | ✓ | ✓ | Effort estimation |
| Created | ✓ | ✓ | Issue creation date |
| Updated | ✓ | ✓ | Last modification date |
| Resolved | ✓ | ✓ | Resolution date (for cycle time) |
| URL | ✓ | ✓ | Clickable HYPERLINK to issue |

---

## Step 2: Comment Enrichment

Fetches the last comment for each issue via the Jira REST API. Run in batches to avoid timeouts.

```bash
# Enrich first 100 rows
python3 scripts/enrich_comments.py --file reports/biro_epics_YYYY-MM-DD.csv --start 1 --end 100

# Next 100
python3 scripts/enrich_comments.py --file reports/biro_epics_YYYY-MM-DD.csv --start 101 --end 200

# Same for tasks
python3 scripts/enrich_comments.py --file reports/biro_tasks_YYYY-MM-DD.csv --start 1 --end 100
python3 scripts/enrich_comments.py --file reports/biro_tasks_YYYY-MM-DD.csv --start 101 --end 200
```

### Script: `enrich_comments.py`

| Argument | Required | Description |
|----------|----------|-------------|
| `--file` / `-f` | Yes | CSV file to enrich |
| `--start N` | No | First row (1-based, default: 1) |
| `--end N` | No | Last row (inclusive, default: all) |
| `--token` | No | Override JIRA_TOKEN |
| `--force` | No | Re-fetch already-enriched rows |

**Columns added**: `Last Comment By`, `Last Comment Date`, `Last Comment` (200 char truncation).

**Notes**:
- Safe to re-run — skips rows that already have comment data unless `--force`.
- ~1 second per issue. Process 50–100 per batch.
- Saves in-place.

---

## Step 3: Computed Columns

Adds calculated metrics based on dates in the CSV.

```bash
python3 scripts/add_computed_columns.py reports/biro_epics_YYYY-MM-DD.csv
python3 scripts/add_computed_columns.py reports/biro_tasks_YYYY-MM-DD.csv
```

### Script: `add_computed_columns.py`

Takes a single argument: the CSV file path. Adds three columns:

| Column | Formula | Description |
|--------|---------|-------------|
| `Age (days)` | `today - Created` | How old the issue is |
| `Cycle Time (days)` | `Resolved - Created` | Days from creation to resolution (Done only) |
| `Stale` | `today - Updated > 30` and status not Done/Cancelled | Yes/No flag for abandoned open issues |

---

## Step 4: Markdown Report

Generates a comprehensive `.md` analysis covering both epics and tasks.

```bash
cd /path/to/project
python3 scripts/biro_full_report.py > reports/biro_analysis_YYYY-MM-DD.md
```

### Script: `biro_full_report.py`

**Reads**: `reports/jira-analysis/csv/biro_epics_YYYY-MM-DD.csv` and `reports/jira-analysis/csv/biro_tasks_YYYY-MM-DD.csv`

**Report sections (per issue type)**:
1. Status Overview — breakdown table with percentages
2. Epic Link Coverage (tasks only) — linked vs orphaned
3. Ownership & Workload — assignee table with status breakdown
4. Cycle Time — avg/median/min/max + distribution buckets
5. Staleness — stale count, by-status breakdown, top 10 stalest items
6. Label Analysis — label distribution table
7. Recommendations — specific actionable items with counts
8. General Observations — data-backed insights

**Notes**: Hardcoded to read from `reports/biro_*` files. Update filenames in the script if analysing a different project.

---

## Step 5: Word Executive Readout

Generates a professional Word document with formatted tables.

```bash
python3 scripts/biro_executive_docx.py
```

### Script: `biro_executive_docx.py`

**Requires**: `python-docx` (`pip3 install python-docx`)

**Output**: `reports/jira-analysis/docx/biro_executive_readout_YYYY-MM-DD.docx`

**Document structure**:
- Title page (project name, date, data source)
- Executive Summary (6 key findings)
- Part 1: Epic Analysis (status, ownership, cycle time, staleness, labels)
- Part 2: Task Analysis (status, epic coverage, ownership, cycle time, staleness)
- Recommendations (quick wins + medium term)
- General Observations (7 data-backed insights)

**Notes**: Uses "Light Grid Accent 1" table style. Calibri 11pt default font.

---

## Quick Reference: Full Pipeline

```bash
export JIRA_TOKEN="<from tokens/tokens.md>"

# 1. Pull data
python3 scripts/jira_query.py --jql "project = BIRO AND issuetype = Epic ORDER BY created DESC" --max 200 --output csv --columns "Key,Summary,Status,Resolution,Priority,Assignee,Reporter,Labels,Components,Story Points,Created,Updated,Resolved,URL" > reports/biro_epics_2026-03-18.csv

python3 scripts/jira_query.py --jql "project = BIRO AND issuetype = Task ORDER BY created DESC" --max 200 --output csv --columns "Key,Summary,Status,Resolution,Priority,Assignee,Reporter,Epic,Labels,Components,Story Points,Created,Updated,Resolved,URL" > reports/biro_tasks_2026-03-18.csv

# 2. Enrich comments (batched)
python3 scripts/enrich_comments.py -f reports/biro_epics_2026-03-18.csv --start 1 --end 100
python3 scripts/enrich_comments.py -f reports/biro_epics_2026-03-18.csv --start 101 --end 200
python3 scripts/enrich_comments.py -f reports/biro_tasks_2026-03-18.csv --start 1 --end 100
python3 scripts/enrich_comments.py -f reports/biro_tasks_2026-03-18.csv --start 101 --end 200

# 3. Add computed columns
python3 scripts/add_computed_columns.py reports/biro_epics_2026-03-18.csv
python3 scripts/add_computed_columns.py reports/biro_tasks_2026-03-18.csv

# 4. Generate markdown report
python3 scripts/biro_full_report.py > reports/biro_analysis_2026-03-18.md

# 5. Generate Word executive readout
python3 scripts/biro_executive_docx.py
```

---

## Step 6: Team Activity Pull (Cross-Project)

Pulls all Jira activity for every team member across ALL projects (not just BIRO).

```bash
export JIRA_TOKEN="<from tokens/tokens.md>"
python3 scripts/team_activity_pull.py
```

### Script: `team_activity_pull.py`

**Reads**: Team roster hardcoded in script (from `reports/biro-team.md`)  
**Output**: `reports/jira-analysis/csv/biro_team_activity_YYYY-MM-DD.csv`

**Columns**: Person, Group, Division, Manager + all standard Jira columns (Key, Project, Type, Status, etc.)

**Notes**:
- Queries each team member with `assignee = {username} AND updated >= -120d`
- Max 200 issues per person
- Includes person metadata: group (Executive/Core/Direct/Regional), division, manager
- Run `add_computed_columns.py` after to add Age, Cycle Time, Stale

---

## Step 7: Team Markdown Report

Generates a comprehensive team activity analysis from the master CSV.

```bash
python3 scripts/team_analysis.py
```

### Script: `team_analysis.py`

**Reads**: `reports/jira-analysis/csv/biro_team_activity_YYYY-MM-DD.csv`  
**Output**: `reports/jira-analysis/biro_team_analysis_YYYY-MM-DD.md`

**Report sections**:
1. Activity by Person — ranked table with total/done/in-progress/stale + projects
2. Activity by Division — division comparison table
3. Activity by Jira Project — which boards, how many issues, who
4. Overall Status Distribution — team-wide status breakdown
5. Cycle Time Analysis — per-person avg/median/min/max (with definition)
6. Stale Issues — stale count by person
7. Workload Balance — top contributors, minimal activity flagged
8. Key Observations — zero-activity members, regional gaps, cross-project spread

---

## Step 8: Team Executive Readout with Charts

Generates a Word document with embedded matplotlib charts.

```bash
python3 scripts/team_executive_docx.py
```

### Script: `team_executive_docx.py`

**Requires**: `python-docx` + `matplotlib`  
**Reads**: `reports/jira-analysis/csv/biro_team_activity_YYYY-MM-DD.csv`  
**Output**:
- `reports/jira-analysis/docx/biro_team_executive_YYYY-MM-DD.docx` — Word document
- `reports/jira-analysis/charts/*.png` — Chart images (reusable in presentations)

### Charts Generated

| Chart | Type | File | Description |
|-------|------|------|-------------|
| Activity by Person | Horizontal bar | `activity_by_person.png` | Issue count per person, color-coded by group (Core/Direct/Regional) |
| Activity by Division | Stacked bar | `activity_by_division.png` | Done vs In Progress vs Other per division |
| Activity by Project | Horizontal bar | `activity_by_project.png` | Issue count per Jira project |
| Status Distribution | Pie chart | `status_distribution.png` | Team-wide status proportions |
| Cycle Time by Person | Horizontal bar | `cycle_time_by_person.png` | Average cycle time per person (fastest first) |

### Document Structure
- Title page (team name, date, dataset summary)
- Executive Summary (5 key metrics)
- Activity by Person (chart + table)
- Activity by Division (chart + table)
- Activity by Jira Project (chart)
- Status Distribution (pie chart)
- Cycle Time Analysis (chart + definition)
- Key Observations (6 data-backed insights)

### Chart Colors
- **Core team**: Dark blue (`#003366`)
- **Direct reports**: Medium blue (`#336699`)
- **Regional**: Teal (`#669999`)
- **Status**: Done=green, In Progress=blue, Backlog=orange, To Do=red

---

## Quick Reference: Full Team Pipeline

```bash
export JIRA_TOKEN="<from tokens/tokens.md>"

# 1. Pull all team activity (last 120 days, all projects)
python3 scripts/team_activity_pull.py

# 2. Add computed columns
python3 scripts/add_computed_columns.py reports/biro_team_activity_2026-03-19.csv

# 3. Generate markdown report
python3 scripts/team_analysis.py

# 4. Generate Word executive readout with charts
python3 scripts/team_executive_docx.py
```

---

## Analysis Quality Guidelines

When generating reports (Steps 4, 5, 7, 8), go beyond surface-level counts and percentages. Every report MUST include:

### Causal Analysis
For every significant finding, explain WHY it exists. Do not just state "20% of issues are stale" — investigate:
- What systemic factors contribute? (staffing gaps, unclear ownership, process breakdowns)
- Are there upstream blockers causing downstream staleness?
- Does the pattern correlate with specific teams, service lines, or time periods?
- Use evidence from the data to support causal claims (e.g., "Team X's stale rate spiked after the Q1 reorg based on created-date clustering")

### Non-obvious Pattern Detection
Look beyond the obvious metrics. Use these specific analytical techniques:
- **Cross-dimensional correlation**: Compare assignee workload vs cycle time — do overloaded people have slower cycle times? Is there a threshold where quality drops?
- **Relative performance benchmarking**: Compare service lines against each other. If Tradecraft resolves 90% but Advisory only 60%, what structural difference explains it?
- **Status-reality mismatch detection**: Find epics marked "In Progress" whose subtasks are all stale or unstarted. The epic status is a lie — flag it.
- **Reporter-Assignee pattern analysis**: Who creates work vs who does it? Is the Service Owner (reporter) doing too much execution? Are certain reporters generating disproportionate work?
- **Labeling entropy analysis**: Compare label consistency across issues. Inconsistent labeling (some have labels, some don't) suggests process gaps that make data unreliable.
- **Temporal clustering**: Look for bursts of issue creation or resolution. Do they cluster around deadlines, reorgs, or specific events?
- **The "healthy team" trap**: Even in well-performing data, look for early warning signs — a service line that's slightly slower, a person who's at 90% capacity, a documentation backlog that's growing. Small cracks precede big failures.

### Trend Forecasting
Project forward based on available data:
- At current resolution velocity, when will the backlog be cleared?
- Is the backlog growing or shrinking? What's the net flow rate?
- Are cycle times improving or degrading over time?
- What are the staffing implications if current trends continue?
- Flag time-sensitive items that will become critical if not addressed soon

### Visualization Recommendations
For each major finding, recommend the best chart type and explain why:
- Stacked bar charts for status distribution by assignee (shows both volume and composition)
- Burndown/burnup lines for velocity trends over time
- Heatmaps for workload concentration by person × service line
- Scatter plots for cycle time vs issue age (reveals outliers)
- Gantt-style timeline charts for epic progress tracking
- Treemaps for hierarchical label/component distribution

### Actionable Recommendations
Every recommendation MUST be:
- **Specific**: Name the exact issues, people, or service lines involved
- **Prioritized**: Rank by urgency and expected impact (P1/P2/P3)
- **Owned**: Suggest who should own each action
- **Time-bound**: Include a recommended timeline (this week / 30 days / this quarter)
- **Impact-quantified**: State the expected outcome (e.g., "Reassigning 5 tasks from X to Y would reduce X's cycle time by ~30%")

### Before You Finish — Self-Check
Before finalizing any report, verify you have included ALL of the following:
- [ ] At least 3 causal explanations (WHY, not just WHAT)
- [ ] At least 2 non-obvious patterns that a casual reader would miss
- [ ] At least 1 forward-looking trend projection with quantified timeline
- [ ] A dedicated "Recommended Visualizations" section listing 3-5 specific charts with:
  - Chart type (bar, line, heatmap, scatter, etc.)
  - What data it would show
  - What insight it would reveal that tables alone cannot
- [ ] 5-7 prioritized recommendations each with owner, timeline, and expected impact

---

## Analysis Capabilities

The following analyses are performed on the enriched data:

| Analysis | Metric | Section |
|----------|--------|---------|
| Status distribution | Count + % per status | Overview |
| Resolution breakdown | Done, Duplicate, Won't Do, Cancelled | Overview |
| Priority distribution | Count + % per priority level | Overview (tasks) |
| Epic link coverage | Linked vs orphaned tasks, top epics by task count | Epic Coverage |
| Ownership & workload | Assigned vs unassigned, per-assignee breakdown by status | Ownership |
| Cycle time | Avg, median, min, max + distribution buckets | Cycle Time |
| Staleness | Count, by-status, top 10 stalest items | Staleness |
| Label distribution | Per-label count | Labels |
| Comment coverage | % of issues with documented discussions | Observations |
| Workload balance | Top assignee concentration % | Observations |
| Story point usage | Whether estimation is being used | Observations |
