# Evaluation Rubric — Jira Analysis v1

## Scoring Scale
- **0** = Completely absent or wrong
- **25** = Poor, major gaps
- **50** = Adequate but unremarkable
- **75** = Good, solid work
- **100** = Exceptional, best-in-class

## Dimensions

| Dimension | Weight | Description |
|-----------|--------|-------------|
| Depth of Analysis | 15% | Goes beyond surface-level stats (counts, percentages) into structural insights about team dynamics, workflow health, and organizational patterns. Connects multiple data points to form a coherent narrative. |
| Causal Insights | 15% | Identifies WHY patterns exist, not just WHAT they are. Proposes root causes for bottlenecks, stale issues, uneven workload. Uses evidence from the data to support causal claims. |
| Non-obvious Patterns | 15% | Finds things a casual reader would miss: hidden correlations, seasonal effects, team composition impacts, labeling inconsistencies that mask real issues, silent failures in process. |
| Risk and Bottleneck Flagging | 15% | Explicitly identifies blockers, single-points-of-failure, capacity risks, deadline risks, and process breakdowns. Quantifies severity and urgency. Flags issues before they become crises. |
| Trend Forecasting | 10% | Projects trajectory based on available data: velocity trends, backlog growth rate, resolution rate changes, staffing implications. Makes forward-looking statements grounded in data. |
| Visualization Choices | 10% | Recommends or uses the right chart types for the data and audience. Explains why specific visualizations are chosen. Suggests charts that would reveal insights not visible in tables. |
| Actionable Recommendations | 15% | Provides executive-ready, specific, prioritized actions with clear owners and timelines. Goes beyond "fix this" to "here's how, here's who, here's when, here's the expected impact." |
| Clarity and Structure | 5% | Well-organized with clear sections, concise language, executive summary up front, progressive detail. Readable by both technical and non-technical stakeholders. |

## Judging Notes

- Dimension names in scores JSON must match exactly: `Depth of Analysis`, `Causal Insights`, `Non-obvious Patterns`, `Risk and Bottleneck Flagging`, `Trend Forecasting`, `Visualization Choices`, `Actionable Recommendations`, `Clarity and Structure`
- The judge should evaluate based on what the skill INSTRUCTS the agent to produce, not just what a single output contains
- Higher weight dimensions (15%) reflect areas Paul specifically wants to improve
- Lower weight dimensions (5-10%) are important but already adequate or secondary focus
