# Skills Lab

**Autonomous skill improvement through iterative search.**

The Skills Lab is a reusable framework for running overnight training campaigns on any Cline skill file (`.md`). It applies the autoresearch paradigm — propose one focused change, evaluate mechanically, keep if better, revert if worse, repeat — to continuously improve the quality of skill-driven outputs.

## How It Works

```
┌─────────────────────────────────────────────────────────┐
│                    THE TRAINING LOOP                     │
│                                                          │
│  1. READ STATE                                           │
│     ├── skill.md (current version)                       │
│     ├── results.tsv (history of scores)                  │
│     ├── checkpoint.json (resume point)                   │
│     └── campaign_brief.md (goals & focus areas)          │
│                                                          │
│  2. PROPOSE ONE CHANGE                                   │
│     ├── Analyze weakest scoring dimensions               │
│     ├── Draft a single, focused edit to skill.md         │
│     └── State the hypothesis                             │
│                                                          │
│  3. APPLY EDIT                                           │
│     └── Modify skill.md only                             │
│                                                          │
│  4. EVALUATE (python run_eval.py)                        │
│     ├── For each test case:                              │
│     │   ├── Generate output using skill + test data      │
│     │   ├── Judge output against rubric (LLM judge)      │
│     │   └── Score per dimension (0-100)                  │
│     ├── Weighted average across dimensions & cases        │
│     └── Print FINAL_SCORE: XX.X                          │
│                                                          │
│  5. DECIDE                                               │
│     ├── FINAL_SCORE > best? → git commit ✅              │
│     └── FINAL_SCORE ≤ best? → git revert ❌              │
│                                                          │
│  6. LOG to results.tsv + update checkpoint.json          │
│                                                          │
│  7. REPEAT (up to N iterations)                          │
└─────────────────────────────────────────────────────────┘
```

## Quick Start

### 1. Start a New Campaign

```bash
# Copy the template
cp -r general/skills-lab/template general/skills-lab/campaigns/my-skill-v1

# The researcher will run the kickoff wizard to populate:
#   - config.yaml (goal, iterations, model)
#   - campaign_brief.md (what to improve, what to protect)
#   - eval_rubric.md (scoring dimensions & weights)
#   - test_cases/ (synthetic or real data scenarios)
```

### 2. Run Training

Use `researcher.md` as the guiding skill. The agent will:
- Read the campaign config
- Execute the loop for N iterations
- Save checkpoints for resume capability

### 3. Review Results

```bash
# Check the score history
cat general/skills-lab/campaigns/my-skill-v1/results.tsv

# See the git log of accepted changes
git log --oneline campaigns/my-skill-v1/skill.md
```

## Folder Structure

```
skills-lab/
├── README.md                 # This file
├── researcher.md             # Meta-skill: instructs the agent running the loop
├── lib/                      # Shared evaluation infrastructure
│   ├── judge.py              # LLM-as-judge via AWS Bedrock
│   ├── generate_output.py    # Runs a skill against test case data
│   ├── run_eval.py           # Orchestrator: generate → judge → FINAL_SCORE
│   └── requirements.txt      # Python dependencies
├── template/                 # Duplicate per new campaign
│   ├── config.yaml           # Campaign parameters
│   ├── campaign_brief.md     # Goals from kickoff wizard
│   ├── skill.md              # THE FILE BEING OPTIMIZED
│   ├── eval_rubric.md        # Scoring dimensions & weights
│   ├── test_cases/           # Input data scenarios
│   ├── outputs/              # Generated outputs per iteration
│   ├── checkpoint.json       # Resume support
│   └── results.tsv           # Iteration log
└── campaigns/                # Active & completed runs
```

## Infrastructure

- **Backend**: AWS Bedrock (us-east-1)
- **Model**: anthropic.claude-opus-4-6-v1
- **Auth**: AWS session credentials (VIP-authenticated, ~4h timeout)
- **Judging**: LLM-as-judge with temperature=0 for reproducibility
- **Version control**: Git branch per campaign, commit winners, revert losers

## Session Timeout Handling

AWS sessions expire after ~4 hours. The system saves `checkpoint.json` after every iteration so you can resume exactly where you left off. No work is ever lost.
